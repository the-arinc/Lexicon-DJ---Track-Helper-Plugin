Official [Lexicon](https://www.lexicondj.com) plugin documentation can be found [here](https://www.lexicondj.com/docs/developers/plugin).
