const choice1 = _settings['Choice #1']
const choice2 = _settings['Choice #2']

_helpers.Report(`Choice #1 result: ${choice1}, choice #2 result: ${choice2}`)
